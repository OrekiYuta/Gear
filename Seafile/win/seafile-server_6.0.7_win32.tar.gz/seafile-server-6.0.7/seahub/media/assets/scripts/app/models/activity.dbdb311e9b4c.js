define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var Activity = Backbone.Model.extend({});

    return Activity;
});
