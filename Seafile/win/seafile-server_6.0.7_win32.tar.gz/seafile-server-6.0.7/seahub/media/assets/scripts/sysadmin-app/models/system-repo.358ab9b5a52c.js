define([
    'underscore',
    'backbone',
    'common'
], function(_, Backbone, Common) {
    'use strict';

    var SystemRepo = Backbone.Model.extend({});

    return SystemRepo;
});
