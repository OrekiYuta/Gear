prettyPrint();

$('.js-tooltip').tooltip({
    delay: 1000
});
