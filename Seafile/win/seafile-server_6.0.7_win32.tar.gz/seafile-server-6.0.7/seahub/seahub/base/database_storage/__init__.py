# Copyright (c) 2012-2016 Seafile Ltd.
# Allow users to: from database_storage import DatabaseStorage
# (reduce redundancy a little bit)

from database_storage import *
